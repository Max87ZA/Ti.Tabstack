//
//  SkMaxappTitabstack.h
//  TiTabstack
//
//  Created by Marian Kucharcik
//  Copyright (c) 2025 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SkMaxappTitabstack.
FOUNDATION_EXPORT double SkMaxappTitabstackVersionNumber;

//! Project version string for SkMaxappTitabstack.
FOUNDATION_EXPORT const unsigned char SkMaxappTitabstackVersionString[];

#import "SkMaxappTitabstackModuleAssets.h"
